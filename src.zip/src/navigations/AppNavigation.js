import React from 'react';
import { AsyncStorage, View, Image, Text, Animated, Easing, TouchableOpacity, SafeAreaView } from 'react-native';

import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import Splash from '../screen/SplashScreen';
// import AppTutorialScreen from '../Screens/AppTutorialScreen';
// import FirstScreen from '../Screens/FirstScreen';
// import ChooseScreen from '../Screens/ChooseScreen';
// import LoginScreen from '../Screens/LoginScreen';
// import RegisterScreen from '../Screens/RegisterScreen';
// import OtpScreen from '../Screens/OtpScreen';
// import BottomTabNavigator from '../Navigations/BottomTabNavigator';
// import IcoCalculation from '../Screens/TabScreen/HomeScreen/IcoCalculation';
const SplashStack = createStackNavigator(
    {
      Splash: {
        screen:Splash,
        navigationOptions: ({navigation}) => ({
          header: null
        })
      }
    }, {
    initialRouteName: 'Splash'
  }
  )

//    const AuthStack = createStackNavigator({
   
//         FirstScreen: {
//             screen: FirstScreen,
//             navigationOptions:()=>({
//               header: null,
           
//             }) 
//           },
//           ChooseScreen: {
//             screen: ChooseScreen,
//             navigationOptions:()=>({
//               header: null,
           
//             }) 
//           },
//           LoginScreen: {
//             screen: LoginScreen,
//             navigationOptions:()=>({
//               header: null,
           
//             }) 
//           },
//           RegisterScreen: {
//             screen: RegisterScreen,
//             navigationOptions:()=>({
//               header: null,
           
//             }) 
//           },
//           OtpScreen: {
//             screen: OtpScreen,
//             navigationOptions:()=>({
//               header: null,
           
//             }) 
//           },
//           initialRouteName: 'FirstScreen'
//         })

       
        // const AppStack = createStackNavigator({
        //   BottomTabNavigator: {
        //     screen : BottomTabNavigator,
        //     navigationOptions:{
        //       header:null,
        //     }
        //   },
        
         
        // },
        //   {
        //     initialRouteName: 'BottomTabNavigator',
           
        //   }
        // ) 
      

    export default createAppContainer(createSwitchNavigator({
        Splash: Splash,
       
      // Auth :AuthStack,

      }),
        {
          initialRouteName: 'AuthStack',
        }
      );