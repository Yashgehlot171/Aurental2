import React, { Component } from 'react'
import { Platform, StyleSheet,StatusBar, Text, View, Alert, ImageBackground, Image, AsyncStorage, ActivityIndicator } from 'react-native';

export default class App extends Component {


    componentDidMount() {
        setTimeout(() => {
            //  this._retrieveData();{}
            {
                this.props.navigation.navigate("ExamScreen");
            }
        }, 3000)
    }

    render() {
        return (
            <View style={styles.container}>
                  <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />
              
                  {/* <ImageBackground style={{width:'100%',height:'100%',flex:1, }} source={require('../Assets/dark_BG.png')}> */}


                    <View style={{
                        flex: 1, justifyContent:'center',alignItems:'center'
                    }} >
{/*                 
                <Image  style={{width:'100%',height:150,resizeMode:'contain',marginTop:30}} source={require('../Assets/fya_logoActive.png')}></Image> */}
                {/* <Image  style={{width:'100%',height:65,resizeMode:'contain',marginTop:5}} source={require('../Assets/planet.png')}></Image> */}


            </View>
            {/* </ImageBackground> */}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',backgroundColor:'red'
      
    },
    welcome: {
        fontSize: 20,
        textAlign: 'center',
        margin: 10,
    },
    instructions: {
        textAlign: 'center',
        color: '#333333',
        marginBottom: 5,
    },
    headerStyle: {
        width: 150,
        height: 150,
    },
});