import React, { Component } from 'react'
import { TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native';
import { Platform, StyleSheet, StatusBar, Text, View, Alert, ImageBackground, Image, AsyncStorage, ActivityIndicator } from 'react-native';

export default class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            showpassword: true
        }
    }

    render() {
        return (
            <View style={{flex:1}}>
            <StatusBar
                backgroundColor="white"
                barStyle="dark-content"
            />
            <SafeAreaView/>
            <View style={styles.cont}>
                {/* <ImageBackground style={styles.img1} resizeMode="contain" source={require('../Icons/truck_file/truck.png')}  /> */}
        
            <TouchableOpacity style={styles.loginCont0} onPress={() =>props.navigation.navigate('Register')} >
                <Text style={styles.loginCont01} >Are you driver ?</Text>
            </TouchableOpacity >
            {/* <ImageBackground style={styles.img2} resizeMode="contain" source={require('../Icons/truck_file/parcel.png')} /> */}
          
            <TouchableOpacity style={styles.loginCont02} onPress={() =>props.navigation.navigate('CustRegister')}> 
              <Text style={styles.loginCont01} >Have parcel to deliver ?</Text>
          </TouchableOpacity> 
          </View>
          </View>
        );
    }
}




    const styles = StyleSheet.create({
        cont: {
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'white',
        },
        img1: {
            width: 200,
            height: 140,
            marginTop:500,
        
        },
        img2: {
            width: 200,
            height: 140,
          
        },
        loginCont0: {
           
            paddingHorizontal: 75,
            marginTop: 40,
            backgroundColor: '#0072ab',
            paddingVertical: 20,
            borderRadius: 5,
            marginBottom:150
        },
        loginCont02: {
           
            paddingHorizontal: 50,
            marginTop: 40,
            backgroundColor: '#0072ab',
            paddingVertical: 20,
            borderRadius: 5,
            marginBottom:500
        },
        loginCont01: {
            textAlign: 'center',
            color: 'white',
        },
       
        
    });
    













