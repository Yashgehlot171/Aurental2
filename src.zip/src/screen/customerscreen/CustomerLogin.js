import React, { Component } from 'react'
import { TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView ,ScrollView} from 'react-native';
import { Platform, StyleSheet, StatusBar, Text, View, Alert, ImageBackground, Image, AsyncStorage, ActivityIndicator } from 'react-native';

export default class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            showpassword: true
        }
    }

  

//   const f1 = useRef(null);
//   const f2 = useRef(null);
 
//     const handleSignIn = () => {
//         if (data.email === '') {
//             f1.current.focus();
//         } else if (data.password === '') {
//             f2.current.focus();
//         } else {
//             // alert(data.email)
   
//             var myHeaders = new Headers();
//             myHeaders.append("Content-Type", "application/json");
//             myHeaders.append("Authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl9pZCI6MSwidHlwZSI6ImRldmljZSIsImlhdCI6MTYxNjU2MjM2NX0.n8dGBHbi9_I6JObUpSEa2k-fC-mcwVK-JFh920344_o");

//             var raw = JSON.stringify({
//             "email": data.email,
//             "password": data.password
//             });

//             var requestOptions = {
//             method: 'POST',
//             headers: myHeaders,
//             body: raw,
//             redirect: 'follow'
//             };

//             fetch("http://ec2-54-251-142-179.ap-southeast-1.compute.amazonaws.com:6060/api/v1/aurental/login", requestOptions)
//             .then(response => response.json())
//             .then(result => {
                
//                 if (result.status === 0) {
//                     alert("Incorrect Password !!!");
//                 } else if (result.status === 1) {
//                     props.navigation.navigate('Welcome')
//                 } else {
//                     alert(result.message);
//                 }
//             })
//             .catch(error => console.log('error', error));
//         }}

render() {
    return (
        <View style={{flex:1}}>
        <StatusBar
            backgroundColor="white"
            barStyle="dark-content"
        />
        <ScrollView style={styles.cont}>
            <Text style={styles.head}>Log in</Text>
            <View style={styles.imgCont}>
                <ImageBackground style={styles.img} resizeMode="contain" source={require('../Icons/appIcon2.jpg')} />
            </View>
            <View style={styles.viewCont0}>
                <TextInput style={styles.viewCont01} placeholder="E-Mail Address" placeholderTextColor="lightgrey" ref={f1} value={data.email} onChangeText={e => setData({ ...data, email: e})} />
            </View>
            <View style={styles.viewCont0}>
            <TextInput
                                    style={[styles.auth_textInput,]}
                                    onChangeText={(email) => this.setState({ email })}
                                    value={this.state.email}
                                    placeholder="Username or Email"
                                    placeholderTextColor={Colors.text_white}
                                    autoCapitalize='none' />
               <TouchableOpacity onPress={()=>setshowpassword(!showpassword)}>
                <Image style={styles.viewCont011} resizeMode="contain" source={require('../Icons/PNG/eye-pass.png')}  />
            </TouchableOpacity>
            </View>
            <View style={styles.textCont0}>
                <TouchableOpacity style={styles.textCont01}  onPress={() =>props.navigation.navigate('CustWelcome')}>
                    <Text style={styles.textCont011}>
                        Forgot password?
                    </Text>
                </TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.loginCont0} onPress={handleSignIn}>
                <Text style={styles.loginCont01} >Log In</Text>
            </TouchableOpacity>
            <View style={styles.orText0}>
                <Text style={styles.orText01}>or</Text>
            </View>
            <View style={styles.socialCont0}>
                <View style={styles.socialCont01}>
                    {/* <Image style={styles.socialCont011} resizeMode="contain" source={require('../Icons/Google__G__Logo.png')} /> */}
                </View>
                <View style={styles.socialCont01}>
                    {/* <Image style={styles.socialCont011} resizeMode="contain" source={require('../Icons/apple_logo_PNG19666.png')} /> */}
                </View>
                <View style={styles.socialCont01}>
                    {/* <Image style={styles.socialCont011} resizeMode="contain" source={require('../Icons/facebook-logo-icon-facebook-logo-png-transparent-svg-vector-bie-supply-15.png')} /> */}
                </View>
            </View>
            <View style={styles.signUpCont0}>
                <View style={styles.signUpCont0In}>
                    <Text style={styles.signUpCont01}>Don't have account ?</Text>
                    <TouchableOpacity style={styles.signUpCont02} onPress={() => props.navigation.navigate('Register', {
                        'token':"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl9pZCI6MSwidHlwZSI6ImRldmljZSIsImlhdCI6MTYxNjU2MjM2NX0.n8dGBHbi9_I6JObUpSEa2k-fC-mcwVK-JFh920344_o"
                    })}>
                        <Text style={styles.signUpCont021}>Sign Up</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </ScrollView>

   </View>
    );
  }
}
const styles = StyleSheet.create({
    cont: {
        flex: 1,
        backgroundColor: 'white',
    },
    imgCont: {
        alignItems: 'center',
    },
    img: {
        width: 300,
        height: 140,
        marginTop: 40,
    },
    head: {
        width: '100%',
        marginTop: 30,
        fontSize: 17,
        color: 'grey',
        textAlign: 'center',
    },
    viewCont0: {
        marginHorizontal: 30,
        flexDirection: 'row',
        backgroundColor: '#f7f7f7',
        borderRadius: 5,
        marginBottom: 10,
    },
    viewCont01: {
        flex: 1,
        width: 50,
        height: 50,
        paddingLeft: 15,
        color:"black"
    },
    viewCont011: {
        width: 25,
        height: 25,
        marginTop: 12,
        marginRight: 13,
    },
    textCont0: {
        marginHorizontal: 30,
        alignItems: 'flex-end',
    },
    textCont011: {
        fontSize: 12,
        color: '#b2b2b2',
    },
    loginCont0: {
        marginHorizontal: 60,
        marginTop: 30,
        backgroundColor: '#0072ab',
        paddingVertical: 10,
        borderRadius: 5,
    },
    loginCont01: {
        textAlign: 'center',
        color: 'white',
    },
    orText0: {
        borderBottomWidth: 1,
        borderBottomColor: 'lightgrey',
        marginHorizontal: 30,
        alignItems: 'center',
        marginTop: 30,
    },
    orText01: {
        width: 40,
        position: 'absolute',
        backgroundColor: 'white',
        top: -11,
        color: 'grey',
        textAlign: 'center',
    },
    socialCont0: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginTop: 30,
        marginHorizontal: 10,
    },
    socialCont01: {
        width: '30.33%',
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0.5,
        borderColor: '#d0d0d0',
        borderRadius: 3,
    },
    socialCont011: {
        width: '60%',
        height: '60%',
    },
    signUpCont0: {
        width: '100%',
        marginTop: 20,
        alignItems: 'center',
    },
    signUpCont0In: {
        flexDirection: 'row',
    },
    signUpCont01: {
        fontSize: 12,
        color: '#b5b5b5',
    },
    signUpCont021: {
        fontSize: 12,
        marginLeft: 5,
        textDecorationLine: 'underline',
        color: '#0072ab',
    },
});
